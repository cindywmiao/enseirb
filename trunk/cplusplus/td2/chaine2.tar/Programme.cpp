#include <cstdio>

#include "Chaine.hpp"

void annexe(Chaine s) {
  std::printf("Taille chaine  %d\n", s.taille());
}

int main() {
  Chaine chaine("Une petite");

  annexe(chaine);
}
