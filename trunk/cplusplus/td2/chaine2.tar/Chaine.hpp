#ifndef CHAINE_HPP
#define CHAINE_HPP

class Chaine {
 private:
  char* _donnees;
  unsigned int _taille;

 public:
  Chaine();
  Chaine(const char*);
  ~Chaine();

  unsigned int taille();
};

#endif
